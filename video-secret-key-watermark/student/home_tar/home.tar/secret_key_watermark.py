#!/usr/bin/env python3
import cv2
import numpy as np
import sys
import os
import math

BLOCK = 8
FRAME_STEP = 10
COEFF_POS = (3, 4)
STEP = 45.0


def text_to_bits(text):
    return "".join(format(ord(ch), "08b") for ch in text)


def bits_to_text(bits):
    bits = "".join(c for c in bits if c in "01")
    usable = len(bits) - (len(bits) % 8)
    chars = []
    for i in range(0, usable, 8):
        chars.append(chr(int(bits[i:i + 8], 2)))
    return "".join(chars)


def read_text_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


def get_video_info(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {video_path}")

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    if fps <= 0:
        fps = 15

    cap.release()

    usable_w = width - (width % BLOCK)
    usable_h = height - (height % BLOCK)

    blocks_x = usable_w // BLOCK
    blocks_y = usable_h // BLOCK
    blocks_per_frame = blocks_x * blocks_y

    selected_frames = list(range(0, frame_count, FRAME_STEP))
    capacity = len(selected_frames) * blocks_per_frame

    return {
        "frame_count": frame_count,
        "fps": fps,
        "width": width,
        "height": height,
        "usable_w": usable_w,
        "usable_h": usable_h,
        "blocks_x": blocks_x,
        "blocks_y": blocks_y,
        "blocks_per_frame": blocks_per_frame,
        "selected_frames": selected_frames,
        "capacity": capacity,
    }


def make_positions(video_path, bit_count, key):
    info = get_video_info(video_path)

    if bit_count > info["capacity"]:
        raise RuntimeError(f"Khong du dung luong. Can {bit_count} bit, chi co {info['capacity']} vi tri.")

    rng = np.random.default_rng(int(key))
    selected = rng.choice(info["capacity"], size=bit_count, replace=False)

    positions = []

    for linear in selected:
        frame_order = int(linear // info["blocks_per_frame"])
        block_index = int(linear % info["blocks_per_frame"])
        frame_index = info["selected_frames"][frame_order]
        positions.append((frame_index, block_index))

    return positions


def block_index_to_rc(block_index, blocks_x):
    by = block_index // blocks_x
    bx = block_index % blocks_x
    row = by * BLOCK
    col = bx * BLOCK
    return row, col


def build_frame_map(positions, bits=None):
    frame_map = {}

    for bit_index, (frame_index, block_index) in enumerate(positions):
        if frame_index not in frame_map:
            frame_map[frame_index] = []

        if bits is None:
            frame_map[frame_index].append((bit_index, block_index))
        else:
            frame_map[frame_index].append((bit_index, block_index, bits[bit_index]))

    return frame_map


def set_coeff_parity(coeff, bit):
    q = int(round(float(coeff) / STEP))

    if (q & 1) != int(bit):
        if q >= 0:
            q += 1
        else:
            q -= 1

    return float(q * STEP)


def embed_bit(block, bit):
    block_f = np.float32(block) - 128.0
    dct = cv2.dct(block_f)

    y, x = COEFF_POS
    dct[y, x] = set_coeff_parity(dct[y, x], bit)

    out = cv2.idct(dct) + 128.0
    return np.clip(out, 0, 255).astype(np.uint8)


def extract_bit(block):
    block_f = np.float32(block) - 128.0
    dct = cv2.dct(block_f)

    y, x = COEFF_POS
    q = int(round(float(dct[y, x]) / STEP))

    return str(q & 1)


def cmd_bits(watermark_file):
    watermark = read_text_file(watermark_file)
    bits = text_to_bits(watermark)

    with open("watermark_bits.txt", "w", encoding="utf-8") as f:
        f.write(bits)

    print(f"Watermark: {watermark}")
    print(f"So ky tu: {len(watermark)}")
    print(f"So bit: {len(bits)}")
    print("Da ghi chuoi bit vao watermark_bits.txt")


def cmd_capacity(video_path, watermark_file, key):
    watermark = read_text_file(watermark_file)
    bits = text_to_bits(watermark)
    info = get_video_info(video_path)

    print(f"Video: {video_path}")
    print(f"So frame: {info['frame_count']}")
    print(f"Kich thuoc frame: {info['width']}x{info['height']}")
    print(f"Frame step: {FRAME_STEP}")
    print(f"So frame duoc chon: {len(info['selected_frames'])}")
    print(f"So khoi 8x8 moi frame: {info['blocks_per_frame']}")
    print(f"Tong suc chua: {info['capacity']} bit")
    print(f"Watermark: {watermark}")
    print(f"So bit watermark: {len(bits)}")
    print(f"Khoa bi mat: {key}")

    if info["capacity"] >= len(bits):
        print("KET LUAN: Du dung luong de nhung watermark.")
    else:
        print("KET LUAN: Khong du dung luong de nhung watermark.")


def cmd_positions(video_path, watermark_file, key):
    watermark = read_text_file(watermark_file)
    bits = text_to_bits(watermark)
    positions = make_positions(video_path, len(bits), key)

    print(f"Watermark: {watermark}")
    print(f"So bit: {len(bits)}")
    print(f"Khoa bi mat: {key}")
    print("Danh sach vi tri nhung mau:")

    for frame_index, block_index in positions[:30]:
        print(f"frame={frame_index}, block={block_index}")

    if len(positions) > 30:
        print("...")


def make_writer(output_path, fps, width, height):
    ext = os.path.splitext(output_path)[1].lower()

    if ext == ".avi":
        fourcc = cv2.VideoWriter_fourcc(*"FFV1")
    else:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")

    writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    if not writer.isOpened():
        raise RuntimeError(f"Khong tao duoc video dau ra: {output_path}")

    return writer


def cmd_embed(input_video, output_video, watermark_file, key):
    watermark = read_text_file(watermark_file)
    bits = text_to_bits(watermark)

    info = get_video_info(input_video)
    positions = make_positions(input_video, len(bits), key)
    frame_map = build_frame_map(positions, bits)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {input_video}")

    writer = make_writer(output_video, info["fps"], info["width"], info["height"])

    frame_index = 0
    embedded = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        y_channel = ycrcb[:, :, 0]

        if frame_index in frame_map:
            for _, block_index, bit in frame_map[frame_index]:
                row, col = block_index_to_rc(block_index, info["blocks_x"])

                block = y_channel[row:row + BLOCK, col:col + BLOCK]
                y_channel[row:row + BLOCK, col:col + BLOCK] = embed_bit(block, bit)
                embedded += 1

        ycrcb[:, :, 0] = y_channel
        out_frame = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
        writer.write(out_frame)

        frame_index += 1

    cap.release()
    writer.release()

    with open("watermark_meta.txt", "w", encoding="utf-8") as f:
        f.write(f"WATERMARK={watermark}\n")
        f.write(f"KEY={key}\n")
        f.write(f"WATERMARK_LENGTH={len(watermark)}\n")
        f.write(f"WATERMARK_BITS={len(bits)}\n")
        f.write(f"EMBEDDED_BITS={embedded}\n")
        f.write(f"FRAME_STEP={FRAME_STEP}\n")
        f.write(f"COEFF_POS={COEFF_POS}\n")
        f.write(f"STEP={STEP}\n")

    print(f"Watermark goc: {watermark}")
    print(f"Khoa su dung: {key}")
    print(f"So bit da nhung: {embedded}")
    print(f"Video da nhung: {output_video}")
    print("Da ghi metadata vao watermark_meta.txt")


def cmd_extract(input_video, output_file, watermark_length, key):
    watermark_length = int(watermark_length)
    bit_count = watermark_length * 8

    info = get_video_info(input_video)
    positions = make_positions(input_video, bit_count, key)
    frame_map = build_frame_map(positions, bits=None)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {input_video}")

    bits = ["0"] * bit_count
    read_count = 0
    frame_index = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index in frame_map:
            ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
            y_channel = ycrcb[:, :, 0]

            for bit_index, block_index in frame_map[frame_index]:
                row, col = block_index_to_rc(block_index, info["blocks_x"])

                block = y_channel[row:row + BLOCK, col:col + BLOCK]
                bits[bit_index] = extract_bit(block)
                read_count += 1

        frame_index += 1

    cap.release()

    if read_count < bit_count:
        raise RuntimeError(f"Khong doc du bit. Can {bit_count}, doc duoc {read_count}.")

    watermark = bits_to_text("".join(bits))

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(watermark)

    print("EXTRACTED_WATERMARK=" + watermark)
    print(f"Da ghi ket qua vao {output_file}")


def cmd_psnr(original_video, stego_video):
    cap1 = cv2.VideoCapture(original_video)
    cap2 = cv2.VideoCapture(stego_video)

    if not cap1.isOpened() or not cap2.isOpened():
        raise RuntimeError("Khong doc duoc mot trong hai video.")

    mse_sum = 0.0
    frame_count = 0

    while True:
        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()

        if not ret1 or not ret2:
            break

        if frame1.shape != frame2.shape:
            raise RuntimeError("Hai video khac kich thuoc frame.")

        diff = frame1.astype(np.float64) - frame2.astype(np.float64)
        mse_sum += np.mean(diff ** 2)
        frame_count += 1

    cap1.release()
    cap2.release()

    if frame_count == 0:
        raise RuntimeError("Khong co frame de so sanh.")

    mse = mse_sum / frame_count

    if mse == 0:
        psnr = float("inf")
    else:
        psnr = 10 * math.log10((255 ** 2) / mse)

    with open("psnr.txt", "w", encoding="utf-8") as f:
        f.write(f"PSNR={psnr}\n")

    print(f"PSNR={psnr}")
    print("Da ghi ket qua vao psnr.txt")


def usage():
    print("Cach dung:")
    print("  python3 secret_key_watermark.py bits watermark.txt")
    print("  python3 secret_key_watermark.py capacity input.mp4 watermark.txt 12345")
    print("  python3 secret_key_watermark.py positions input.mp4 watermark.txt 12345")
    print("  python3 secret_key_watermark.py positions input.mp4 watermark.txt 54321")
    print("  python3 secret_key_watermark.py embed input.mp4 watermarked_key.avi watermark.txt 12345")
    print("  python3 secret_key_watermark.py extract watermarked_key.avi extracted_right.txt 15 12345")
    print("  python3 secret_key_watermark.py extract watermarked_key.avi extracted_wrong.txt 15 54321")
    print("  python3 secret_key_watermark.py psnr input.mp4 watermarked_key.avi")


def main():
    if len(sys.argv) < 2:
        usage()
        sys.exit(1)

    cmd = sys.argv[1]

    try:
        if cmd == "bits":
            if len(sys.argv) != 3:
                usage()
                sys.exit(1)
            cmd_bits(sys.argv[2])

        elif cmd == "capacity":
            if len(sys.argv) != 5:
                usage()
                sys.exit(1)
            cmd_capacity(sys.argv[2], sys.argv[3], sys.argv[4])

        elif cmd == "positions":
            if len(sys.argv) != 5:
                usage()
                sys.exit(1)
            cmd_positions(sys.argv[2], sys.argv[3], sys.argv[4])

        elif cmd == "embed":
            if len(sys.argv) != 6:
                usage()
                sys.exit(1)
            cmd_embed(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])

        elif cmd == "extract":
            if len(sys.argv) != 6:
                usage()
                sys.exit(1)
            cmd_extract(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])

        elif cmd == "psnr":
            if len(sys.argv) != 4:
                usage()
                sys.exit(1)
            cmd_psnr(sys.argv[2], sys.argv[3])

        else:
            usage()
            sys.exit(1)

    except Exception as e:
        print("Loi:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
