import cv2
import numpy as np
import sys
import os
import math
import subprocess

MAGIC = b"RBW1"
BLOCK = 8
FRAME_STEP = 5

COEFF_A = (3, 2)
COEFF_B = (2, 3)
DELTA = 35.0


def bytes_to_bits(data: bytes):
    bits = []
    for byte in data:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits


def bits_to_bytes(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for bit in bits[i:i + 8]:
            byte = (byte << 1) | int(bit)
        out.append(byte)
    return bytes(out)


def make_payload(watermark: str):
    data = watermark.encode("utf-8")
    length = len(data).to_bytes(4, byteorder="big")
    return MAGIC + length + data


def set_abs_coeff(dct, pos, target_abs):
    y, x = pos
    sign = 1.0 if dct[y, x] >= 0 else -1.0
    dct[y, x] = sign * float(target_abs)
    return dct


def embed_bit_in_block(block, bit):
    block_f = np.float32(block) - 128.0
    dct = cv2.dct(block_f)

    ay, ax = COEFF_A
    by, bx = COEFF_B

    a = abs(float(dct[ay, ax]))
    b = abs(float(dct[by, bx]))

    if bit == 1:
        if a <= b + DELTA:
            dct = set_abs_coeff(dct, COEFF_A, b + DELTA)
    else:
        if b <= a + DELTA:
            dct = set_abs_coeff(dct, COEFF_B, a + DELTA)

    idct = cv2.idct(dct) + 128.0
    return np.clip(idct, 0, 255).astype(np.uint8)


def extract_bit_from_block(block):
    block_f = np.float32(block) - 128.0
    dct = cv2.dct(block_f)

    ay, ax = COEFF_A
    by, bx = COEFF_B

    a = abs(float(dct[ay, ax]))
    b = abs(float(dct[by, bx]))

    if a > b:
        return 1
    return 0


def iter_blocks(gray):
    height, width = gray.shape
    usable_h = height - (height % BLOCK)
    usable_w = width - (width % BLOCK)

    for row in range(0, usable_h, BLOCK):
        for col in range(0, usable_w, BLOCK):
            yield row, col, gray[row:row + BLOCK, col:col + BLOCK]


def embed_watermark(input_video, output_video, watermark):
    payload = make_payload(watermark)
    bits = bytes_to_bits(payload)
    total_bits = len(bits)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video dau vao: {input_video}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        fps = 15

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"FFV1")
    writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    if not writer.isOpened():
        raise RuntimeError("Khong tao duoc video dau ra. Hay dung .avi voi codec FFV1.")

    frame_index = 0
    carrier_index = 0
    selected_frames = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if frame_index % FRAME_STEP == 0:
            selected_frames += 1
            for row, col, block in iter_blocks(gray):
                bit = bits[carrier_index % total_bits]
                gray[row:row + BLOCK, col:col + BLOCK] = embed_bit_in_block(block, bit)
                carrier_index += 1

        out_frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        writer.write(out_frame)
        frame_index += 1

    cap.release()
    writer.release()

    if carrier_index < total_bits:
        if os.path.exists(output_video):
            os.remove(output_video)
        raise RuntimeError("Video qua ngan, khong du khoi DCT de nhung watermark.")

    with open("watermark_meta.txt", "w", encoding="utf-8") as f:
        f.write(f"WATERMARK={watermark}\n")
        f.write(f"LENGTH={len(watermark)}\n")
        f.write(f"PAYLOAD_BITS={total_bits}\n")
        f.write(f"CARRIERS={carrier_index}\n")
        f.write(f"REPETITIONS={carrier_index / total_bits:.2f}\n")

    print(f"Watermark goc: {watermark}")
    print(f"So bit payload: {total_bits}")
    print(f"So carrier da nhung: {carrier_index}")
    print(f"So lan lap trung binh: {carrier_index / total_bits:.2f}")
    print(f"So frame duoc chon de nhung: {selected_frames}")
    print(f"Video bao ve ban quyen: {output_video}")
    print("Da ghi metadata vao watermark_meta.txt")


def extract_watermark(video_path, watermark_length):
    watermark_length = int(watermark_length)
    total_bits = (8 + watermark_length) * 8

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {video_path}")

    votes = [[] for _ in range(total_bits)]
    frame_index = 0
    carrier_index = 0
    selected_frames = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % FRAME_STEP == 0:
            selected_frames += 1
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            for _, _, block in iter_blocks(gray):
                bit_pos = carrier_index % total_bits
                bit = extract_bit_from_block(block)
                votes[bit_pos].append(bit)
                carrier_index += 1

        frame_index += 1

    cap.release()

    if carrier_index < total_bits:
        raise RuntimeError("Video khong du carrier de trich xuat watermark.")

    recovered_bits = []
    confidence_sum = 0.0
    usable_positions = 0

    for bit_votes in votes:
        if not bit_votes:
            recovered_bits.append(0)
            continue

        ones = sum(bit_votes)
        zeros = len(bit_votes) - ones

        if ones >= zeros:
            recovered_bits.append(1)
            confidence_sum += ones / len(bit_votes)
        else:
            recovered_bits.append(0)
            confidence_sum += zeros / len(bit_votes)

        usable_positions += 1

    payload = bits_to_bytes(recovered_bits)

    if payload[:4] != MAGIC:
        print("Canh bao: MAGIC khong khop. Video co the bi tan cong manh hoac sai do dai watermark.")

    length_from_payload = int.from_bytes(payload[4:8], byteorder="big")
    message = payload[8:8 + watermark_length].decode("utf-8", errors="replace")

    confidence = confidence_sum / max(usable_positions, 1)

    with open("extracted.txt", "w", encoding="utf-8") as f:
        f.write(message + "\n")

    with open("extract_report.txt", "w", encoding="utf-8") as f:
        f.write(f"EXTRACTED_WATERMARK={message}\n")
        f.write(f"EXPECTED_LENGTH={watermark_length}\n")
        f.write(f"LENGTH_FROM_PAYLOAD={length_from_payload}\n")
        f.write(f"CARRIERS_READ={carrier_index}\n")
        f.write(f"SELECTED_FRAMES={selected_frames}\n")
        f.write(f"AVERAGE_VOTE_CONFIDENCE={confidence:.4f}\n")

    print("EXTRACTED_WATERMARK=" + message)
    print(f"Do tin cay bo phieu trung binh: {confidence:.4f}")
    print("Da ghi extracted.txt va extract_report.txt")


def psnr(original_video, watermarked_video):
    cap1 = cv2.VideoCapture(original_video)
    cap2 = cv2.VideoCapture(watermarked_video)

    if not cap1.isOpened() or not cap2.isOpened():
        raise RuntimeError("Khong doc duoc mot trong hai video.")

    mse_sum = 0.0
    frame_count = 0

    while True:
        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()

        if not ret1 or not ret2:
            break

        gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)

        if gray1.shape != gray2.shape:
            raise RuntimeError("Hai video khac kich thuoc frame.")

        diff = gray1.astype(np.float64) - gray2.astype(np.float64)
        mse_sum += np.mean(diff ** 2)
        frame_count += 1

    cap1.release()
    cap2.release()

    if frame_count == 0:
        raise RuntimeError("Khong co frame de so sanh.")

    mse = mse_sum / frame_count

    if mse == 0:
        value = float("inf")
    else:
        value = 10 * math.log10((255 ** 2) / mse)

    with open("psnr.txt", "w", encoding="utf-8") as f:
        f.write(f"PSNR={value}\n")

    print(f"PSNR={value}")
    print("Da ghi ket qua vao psnr.txt")


def attack_compress(input_video, output_video, crf="28"):
    cmd = [
        "ffmpeg", "-y",
        "-i", input_video,
        "-c:v", "libx264",
        "-crf", str(crf),
        "-preset", "veryfast",
        "-an",
        output_video
    ]

    print("Dang nen lai video bang FFmpeg...")
    print(" ".join(cmd))
    subprocess.run(cmd, check=True)
    print(f"Video sau tan cong nen: {output_video}")


def attack_noise(input_video, output_video, sigma="3"):
    sigma = float(sigma)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {input_video}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        fps = 15

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"FFV1")
    writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    rng = np.random.default_rng(2026)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        noise = rng.normal(0, sigma, frame.shape)
        attacked = np.clip(frame.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        writer.write(attacked)

    cap.release()
    writer.release()

    print(f"Video sau tan cong nhieu: {output_video}")


def attack_resize(input_video, output_video, scale="0.75"):
    scale = float(scale)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Khong doc duoc video: {input_video}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        fps = 15

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"FFV1")
    writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    small_w = max(8, int(width * scale))
    small_h = max(8, int(height * scale))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        small = cv2.resize(frame, (small_w, small_h), interpolation=cv2.INTER_AREA)
        restored = cv2.resize(small, (width, height), interpolation=cv2.INTER_LINEAR)
        writer.write(restored)

    cap.release()
    writer.release()

    print(f"Video sau tan cong resize: {output_video}")


def usage():
    print("Cach dung:")
    print("  python3 robust_watermark.py embed input.mp4 protected.avi COPYRIGHT_GROUP_03")
    print("  python3 robust_watermark.py extract protected.avi 18")
    print("  python3 robust_watermark.py attack-compress protected.avi attacked.mp4 28")
    print("  python3 robust_watermark.py attack-noise protected.avi noise_attack.avi 3")
    print("  python3 robust_watermark.py attack-resize protected.avi resize_attack.avi 0.75")
    print("  python3 robust_watermark.py psnr input.mp4 protected.avi")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
        sys.exit(1)

    cmd = sys.argv[1]

    try:
        if cmd == "embed":
            if len(sys.argv) != 5:
                usage()
                sys.exit(1)
            embed_watermark(sys.argv[2], sys.argv[3], sys.argv[4])

        elif cmd == "extract":
            if len(sys.argv) != 4:
                usage()
                sys.exit(1)
            extract_watermark(sys.argv[2], sys.argv[3])

        elif cmd == "psnr":
            if len(sys.argv) != 4:
                usage()
                sys.exit(1)
            psnr(sys.argv[2], sys.argv[3])

        elif cmd == "attack-compress":
            if len(sys.argv) not in [4, 5]:
                usage()
                sys.exit(1)
            crf = sys.argv[4] if len(sys.argv) == 5 else "28"
            attack_compress(sys.argv[2], sys.argv[3], crf)

        elif cmd == "attack-noise":
            if len(sys.argv) not in [4, 5]:
                usage()
                sys.exit(1)
            sigma = sys.argv[4] if len(sys.argv) == 5 else "3"
            attack_noise(sys.argv[2], sys.argv[3], sigma)

        elif cmd == "attack-resize":
            if len(sys.argv) not in [4, 5]:
                usage()
                sys.exit(1)
            scale = sys.argv[4] if len(sys.argv) == 5 else "0.75"
            attack_resize(sys.argv[2], sys.argv[3], scale)

        else:
            usage()
            sys.exit(1)

    except Exception as e:
        print("Loi:", e)
        sys.exit(1)
