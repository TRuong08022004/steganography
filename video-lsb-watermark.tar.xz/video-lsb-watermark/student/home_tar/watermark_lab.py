#!/usr/bin/env python3
import cv2
import numpy as np
import sys
import math
import os

MAGIC = b"LSB1"


def bytes_to_bits(data: bytes):
    bits = []
    for byte in data:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits


def bits_to_bytes(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for bit in bits[i:i + 8]:
            byte = (byte << 1) | int(bit)
        out.append(byte)
    return bytes(out)


def make_payload(watermark: str):
    data = watermark.encode("utf-8")
    length = len(data).to_bytes(4, byteorder="big")
    return MAGIC + length + data


def embed_watermark(input_video, output_video, watermark):
    payload = make_payload(watermark)
    bits = bytes_to_bits(payload)

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        raise RuntimeError(f"Không đọc được video đầu vào: {input_video}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        fps = 15

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"FFV1")
    writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    if not writer.isOpened():
        raise RuntimeError("Không tạo được video đầu ra. Hãy dùng định dạng .avi với codec FFV1.")

    bit_index = 0
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1

        if bit_index < len(bits):
            blue_channel = frame[:, :, 0].reshape(-1)
            remain = len(bits) - bit_index
            n = min(remain, blue_channel.size)

            bit_array = np.array(bits[bit_index:bit_index + n], dtype=np.uint8)
            blue_channel[:n] = (blue_channel[:n] & 0xFE) | bit_array

            bit_index += n

        writer.write(frame)

    cap.release()
    writer.release()

    if bit_index < len(bits):
        if os.path.exists(output_video):
            os.remove(output_video)
        raise RuntimeError("Video quá ngắn, không đủ pixel để nhúng toàn bộ watermark.")

    print(f"Watermark gốc: {watermark}")
    print(f"Số frame đã xử lý: {frame_count}")
    print(f"Số bit đã nhúng: {len(bits)}")
    print(f"Video đã nhúng: {output_video}")


def read_bits(video_path, total_bits):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Không đọc được video: {video_path}")

    bits = []

    while len(bits) < total_bits:
        ret, frame = cap.read()
        if not ret:
            break

        blue_channel = frame[:, :, 0].reshape(-1)
        lsb = blue_channel & 1

        need = total_bits - len(bits)
        bits.extend(lsb[:need].tolist())

    cap.release()

    if len(bits) < total_bits:
        raise RuntimeError("Không đọc đủ bit từ video. Video có thể bị nén mất dữ liệu hoặc bị hỏng.")

    return bits


def extract_watermark(video_path):
    header_bits = read_bits(video_path, 64)
    header = bits_to_bytes(header_bits)

    if header[:4] != MAGIC:
        raise RuntimeError("Không tìm thấy watermark hợp lệ. Có thể video đã bị nén mất LSB.")

    length = int.from_bytes(header[4:8], byteorder="big")
    total_bits = (8 + length) * 8

    all_bits = read_bits(video_path, total_bits)
    payload = bits_to_bytes(all_bits)

    watermark = payload[8:8 + length].decode("utf-8", errors="replace")

    with open("extracted.txt", "w", encoding="utf-8") as f:
        f.write(watermark + "\n")

    print("EXTRACTED_WATERMARK=" + watermark)
    print("Đã ghi kết quả vào file extracted.txt")


def psnr(original_video, watermarked_video):
    cap1 = cv2.VideoCapture(original_video)
    cap2 = cv2.VideoCapture(watermarked_video)

    if not cap1.isOpened() or not cap2.isOpened():
        raise RuntimeError("Không đọc được một trong hai video.")

    mse_sum = 0.0
    frame_count = 0

    while True:
        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()

        if not ret1 or not ret2:
            break

        if frame1.shape != frame2.shape:
            raise RuntimeError("Hai video khác kích thước frame.")

        diff = frame1.astype(np.float64) - frame2.astype(np.float64)
        mse_sum += np.mean(diff ** 2)
        frame_count += 1

    cap1.release()
    cap2.release()

    if frame_count == 0:
        raise RuntimeError("Không có frame để so sánh.")

    mse = mse_sum / frame_count

    if mse == 0:
        value = float("inf")
    else:
        value = 10 * math.log10((255 ** 2) / mse)

    with open("psnr.txt", "w", encoding="utf-8") as f:
        f.write(f"PSNR={value}\n")

    print(f"PSNR={value}")
    print("Đã ghi kết quả vào file psnr.txt")


def usage():
    print("Cách dùng:")
    print("  python3 watermark_lab.py embed input.mp4 watermarked.avi OWNER_GROUP_01")
    print("  python3 watermark_lab.py extract watermarked.avi")
    print("  python3 watermark_lab.py psnr input.mp4 watermarked.avi")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
        sys.exit(1)

    cmd = sys.argv[1]

    try:
        if cmd == "embed":
            if len(sys.argv) != 5:
                usage()
                sys.exit(1)
            embed_watermark(sys.argv[2], sys.argv[3], sys.argv[4])

        elif cmd == "extract":
            if len(sys.argv) != 3:
                usage()
                sys.exit(1)
            extract_watermark(sys.argv[2])

        elif cmd == "psnr":
            if len(sys.argv) != 4:
                usage()
                sys.exit(1)
            psnr(sys.argv[2], sys.argv[3])

        else:
            usage()
            sys.exit(1)

    except Exception as e:
        print("Lỗi:", e)
        sys.exit(1)
